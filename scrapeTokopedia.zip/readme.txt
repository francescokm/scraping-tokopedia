THIS CODE WILL TAKE 100 products of mobilephone from TOKOPEDIA

here is the link :
https://www.tokopedia.com/p/handphone-tablet/handphone

please make sure you have Firefox on your system and should be run in windows machine not mac or linux

and don't remove or delete geckodriver.exe it will couse an error

after write until 100 products it will write in CSV, before, you will not see any CSV list file